
public abstract class Consumable {

	public Consumable() {
		// TODO Auto-generated constructor stub
	}

}
