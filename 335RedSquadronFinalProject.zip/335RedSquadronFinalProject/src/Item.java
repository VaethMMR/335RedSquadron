// 335 Final Project - Red Squadron
// Authors: Alex Guyot and John Oney

public abstract class Item {
	// private variables
	private int cost;
	private String name;
	// private int weight; // TODO: Do we need this?
	
	public Item(int cost, String name) {
		this.cost = cost;
		this.name = name;
	}

}