//package ai;
//
//public class AStarPathfinder implements Pathfinder{
//
//	@Override
//	public PathNode findPath(int[] start) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public Path findPath(int[] start) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public int getDistance(PathNode current, PathNode target) {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//
//}
