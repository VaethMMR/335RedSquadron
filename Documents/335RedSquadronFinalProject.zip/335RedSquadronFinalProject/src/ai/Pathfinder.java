package ai;

import java.util.List;

public interface Pathfinder {

	public List<GridNode> findPath(GridNode start);
}
