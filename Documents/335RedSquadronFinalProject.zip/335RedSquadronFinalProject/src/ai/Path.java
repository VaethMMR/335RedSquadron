package ai;

public class Path {

}
