package ai;

public interface Defensive extends Strategy {
	public void strategy();
}
