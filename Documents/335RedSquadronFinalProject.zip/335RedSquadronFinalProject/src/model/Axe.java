package model;

public class Axe extends Weapon {

	public Axe(String name, int level) {
		super(name, level);
		// TODO Auto-generated constructor stub
	}

}
