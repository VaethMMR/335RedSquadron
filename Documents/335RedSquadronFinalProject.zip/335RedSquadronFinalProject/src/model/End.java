//package model;
//
//import ai.Strategy;
//
//public class End implements Strategy{
//
//	public void strategy(Unit unit, Model model) {
//			//To implement later
//	}
//}
