package model;

public class Lance extends Weapon {

	public Lance(String name, int level) {
		super(name, level);
		// TODO Auto-generated constructor stub
	}

}
