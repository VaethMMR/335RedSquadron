package model;

public class Elemental extends Tome{

	public Elemental(String name, int level) {
		super(name, level);
		// TODO Auto-generated constructor stub
	}

}
