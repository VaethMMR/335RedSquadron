//package model;
//public class heroCreator {
//
//   public static void main(String[] args) {
//      Axereaver Francis = new Axereaver("Francis", "Axereaver", 1, 25, 5, 10, 0, 8, 5, 4, 7, 1);
//      Marksman Austen = new Marksman("Austen", "Marksman", 1, 18, 5, 8, 0, 9, 7, 5, 5, 2);
//      Hero Finch = new Hero("Finch", "Hero", 1, 21, 6, 7, 2, 6, 10, 7, 5, 3);
//      Saint Lane = new Saint("Lane", "Saint", 1, 16, 5, 3, 8, 4, 5, 9, 2, 10);     
//      Sorcerer Lenon = new Sorcerer("Lenon", "Sorcerer", 1, 17, 6, 2, 7, 6, 8, 1, 4, 4); 
//      
//      System.out.println(Finch.toString() + "\n");
//      System.out.println(Lenon.toString());
//}
//}