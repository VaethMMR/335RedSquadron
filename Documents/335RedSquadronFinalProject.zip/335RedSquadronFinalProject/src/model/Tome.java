package model;

public abstract class Tome extends Weapon {

	public Tome(String name, int level) {
		super(name, level);
		// TODO Auto-generated constructor stub
	}

}
