package model;

public class Light extends Tome {

	public Light(String name, int level) {
		super(name, level);
		// TODO Auto-generated constructor stub
	}

}
