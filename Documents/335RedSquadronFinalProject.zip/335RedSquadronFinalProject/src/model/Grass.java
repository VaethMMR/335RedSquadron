package model;
// 335 Final Project - Red Squadron
// Authors: Alex Guyot and John Oney

public class Grass extends Terrain {
	// constructor
	public Grass(int[] location) {
		super(true, location);
	}

}
