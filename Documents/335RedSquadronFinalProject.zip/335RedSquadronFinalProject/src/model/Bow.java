package model;
//335 Final Project - Red Squadron
//Authors: Alex Guyot and John Oney

public class Bow extends Weapon {

	public Bow(int level, String name) {
		super(name, level);
	}
}