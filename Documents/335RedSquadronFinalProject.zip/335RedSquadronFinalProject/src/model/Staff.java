package model;

public class Staff extends Weapon {

	public Staff(String name, int level) {
		super(name, level);
	}

}
