package model;

public class Dirt extends Terrain {

	public Dirt(int[] location) {
		super(true, location);
	}
	
}
