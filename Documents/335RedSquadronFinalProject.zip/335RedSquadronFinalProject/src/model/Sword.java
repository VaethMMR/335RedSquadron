package model;
//335 Final Project - Red Squadron
//Authors: Alex Guyot and John Oney

public class Sword extends Weapon{

	public Sword(int cost, String name) {
		super(name, cost);
	}

}