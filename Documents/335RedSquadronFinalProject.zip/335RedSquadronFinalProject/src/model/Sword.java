package model;
//335 Final Project - Red Squadron
//Authors: Alex Guyot and John Oney

public class Sword extends Weapon{

	public Sword(int level, String name) {
		super(name, level);
	}

}