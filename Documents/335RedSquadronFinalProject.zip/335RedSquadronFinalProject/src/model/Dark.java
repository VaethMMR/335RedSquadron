package model;

public class Dark extends Tome {

	public Dark(String name, int level) {
		super(name, level);
		// TODO Auto-generated constructor stub
	}

}
