package model;
// 335 Final Project - Red Squadron
// Authors: Alex Guyot and John Oney

public abstract class Equipment extends Item {
		
	// constructor
	public Equipment(String name, int level) {
		super(name,level);
	}

}